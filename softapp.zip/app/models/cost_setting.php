<?php
class CostSetting extends AppModel {

    var $name = 'CostSetting';
}