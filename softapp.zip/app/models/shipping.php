<?php
class Shipping extends AppModel {

    var $name = 'Shipping';
    
  }