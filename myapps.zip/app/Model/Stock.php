<?php
class Stock extends AppModel {
	var $name = 'Stock';	 
	
}

?>